# SAVING API JSON TO FILE #

import pandas as pd
import json
import requests

url = 'https://www.bankofcanada.ca/valet/observations/FXUSDCAD?start_date=2018-01-02&end_date=2018-12-31'
response = requests.get(url)
json_data = response.json()
json_data1 = json.dumps(json_data, indent = 2)

with open('2018.json', 'w') as file_writer: 
 json.dump(json_data1,file_writer)

 # GETTING API CALL FROM JSON FILE #

  # import requests, json
 # import pandas as pd

# data_request =  requests.get ("https://www.bankofcanada.ca/valet/observations/FXUSDCAD?start_date=2019-12-02&end_date=2019-12-31")
# data_json= data_request.json()

# package_string = json.dumps(data_json, indent = 2)
# print(package_string)


